import json
from datetime import datetime, timezone
from .db import connect
from .metrics import normalize, weekly

MAX_LISTINGS = 1000

def save(row, watched=False, keyword=None, snapshot=False):
    with connect() as con:
        exists = con.execute('SELECT 1 FROM listings WHERE listing_id=?', (row['listing_id'],)).fetchone()
        if not exists and con.execute('SELECT count(*) FROM listings').fetchone()[0] >= MAX_LISTINGS:
            raise ValueError('1,000 listing limit reached. Remove unused listings before adding more.')
        con.execute('''INSERT INTO listings(listing_id,title,shop_id,payload,watched) VALUES (?,?,?,?,?)
         ON CONFLICT(listing_id) DO UPDATE SET title=excluded.title,shop_id=excluded.shop_id,
         payload=excluded.payload,watched=max(listings.watched,excluded.watched),updated_at=CURRENT_TIMESTAMP''',
                    (row['listing_id'], row['title'], row['shop_id'], json.dumps(row), int(watched)))
        if keyword:
            con.execute('INSERT OR IGNORE INTO keyword_listings VALUES (?,?)', (keyword, row['listing_id']))
        if snapshot:
            now = datetime.now(timezone.utc)
            # Keep the first successful observation each UTC day; reruns are idempotent.
            con.execute('INSERT OR IGNORE INTO snapshots VALUES (?,?,?,?,?,?,?)',
                        (row['listing_id'], now.date().isoformat(), now.isoformat(), row['favorites'],
                         row['quantity'], row['views'], row['shop_sales']))

def enrich(client, item, warnings):
    try:
        shop = client.shop(item['shop_id'])
    except Exception as exc:
        from .etsy import EtsyError
        if not isinstance(exc, EtsyError):
            raise
        warnings.append(f"Shop {item['shop_id']}: {exc}")
        shop = None
    return normalize(item, shop)

def watchlist():
    with connect() as con:
        rows = con.execute('''SELECT * FROM listings WHERE watched=1 OR listing_id IN
                           (SELECT listing_id FROM keyword_listings)''').fetchall()
        out = []
        for record in rows:
            row = json.loads(record['payload'])
            history = [dict(h) for h in con.execute('SELECT * FROM snapshots WHERE listing_id=? ORDER BY day', (row['listing_id'],))]
            row.update(weekly(history))
            row['last_snapshot'] = history[-1]['observed_at'] if history else None
            out.append(row)
        return out
