"""Run from project root: python -m app.daily"""
import logging
import sys
from .db import init, connect
from .etsy import EtsyClient, EtsyError
from .service import enrich, save

log = logging.getLogger(__name__)

def run():
    init()
    client = EtsyClient()
    failures, warnings, collected = [], [], set()
    try:
        with connect() as con:
            keywords = [r[0] for r in con.execute('SELECT keyword FROM keywords')]
        for keyword in keywords:
            try:
                items = client.search(keyword, 20)
                for item in items:
                    row = enrich(client, item, warnings)
                    save(row, keyword=keyword, snapshot=True)
                    collected.add(row['listing_id'])
            except (EtsyError, ValueError) as exc:
                failures.append(f'Keyword {keyword}: {exc}')
        with connect() as con:
            ids = [r[0] for r in con.execute('SELECT listing_id FROM listings WHERE watched=1 OR listing_id IN (SELECT listing_id FROM keyword_listings)')]
        for listing_id in ids:
            if listing_id in collected:
                continue
            try:
                row = enrich(client, client.listing(listing_id), warnings)
                save(row, snapshot=True)
            except (EtsyError, ValueError) as exc:
                failures.append(f'Listing {listing_id}: {exc}')
        for message in sorted(set(warnings + failures)):
            log.warning(message)
        log.info('Daily run: %d discovered listings; %d failures; %d shop warnings', len(collected), len(failures), len(warnings))
        return 1 if failures or warnings else 0
    finally:
        client.close()

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    try:
        sys.exit(run())
    except EtsyError as exc:
        log.error('%s', exc)
        sys.exit(1)
