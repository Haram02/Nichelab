# Personal Etsy Niche Lab

A local FastAPI + Streamlit + SQLite starter. Step 1 works without historical data: keyword search, listing/shop enrichment, sortable metrics, and exact-phrase tag aggregation. Includes targeted watchlists and daily snapshots for subsequent weekly signals. No scraper, paid data service, or external database required.

## Run

Python 3.11+ recommended. From this folder:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

On Windows activate with `.venv\Scripts\activate`. Edit `.env` locally with your approved Etsy app's keystring and shared secret. Never put credentials in chat, browser code, or source control. Etsy's current specification requires `x-api-key: keystring:shared_secret`; this is assembled on the backend. App approval/access is required; a key does not guarantee access to every endpoint. Public endpoints here do not require an OAuth user token.

Start two terminals from this folder with the virtual environment activated:

```bash
uvicorn app.api:app --host 127.0.0.1 --port 8000
```

```bash
streamlit run dashboard.py --server.address 127.0.0.1
```

Open http://localhost:8501. API reference: http://localhost:8000/docs.
Search `editable birthday invitation`. Click headings to sort. Save a keyword or a numeric listing ID under Watchlist. Keyword saves queue discovery for the daily job; saving an individual listing immediately captures its first snapshot. Credentials are read when a client is created; restart both processes after editing configuration.

## Daily collection

Run once manually:

```bash
python -m app.daily
```

Local cron example (replace both paths with your extracted project directory):

```cron
17 4 * * * cd /absolute/path/etsy-tracker && /absolute/path/etsy-tracker/.venv/bin/python -m app.daily >> daily.log 2>&1
```

This runs at 04:17 in the cron host's timezone, not necessarily your local timezone. Use Task Scheduler on Windows. Keep the computer running and back up `data/tracker.sqlite3`. No scheduler has been installed automatically.

Local scheduling is the default because it preserves SQLite reliably. GitHub Actions runners are ephemeral: uploading the DB as a new artifact alone does not restore previous history. If moving collection there, use a persistent PostgreSQL implementation or explicitly download and verify the latest prior database before every run, serialize runs, retain backups, and upload the updated DB even after partial failures. This starter does not implement that migration.

Each job searches up to 20 relevance-ranked listings per keyword, retains discovered IDs to follow them after they leave the top results, and tracks individually saved IDs. At most 50 keywords and 1,000 stored listings. Shops are fetched once per client run. A worst-case 50-keyword/1,000-listing run is approximately 2,050 requests before retries, depending on overlap. A persistent local daily request counter defaults to 4,500; your Etsy app's actual quota and QPS limits remain authoritative and may differ. Manual searches and retries also count. Other applications using the same key are not counted locally. HTTP 429 honors numeric Retry-After up to 30 seconds, otherwise fails for a later retry. Jobs can be rerun safely: the first successful observation per listing/UTC date is retained. Partial failures are logged and cause a nonzero exit; failed observations are never fabricated as zeroes.

Removing a keyword stops discovery, but keeps stored listing history. Listings no longer associated with any keyword and not explicitly watched stop collecting. Remove their IDs to free storage. Removing a listing deletes history and keyword associations; a future keyword search may discover it again.

## Data model

The executable DDL is in `app/db.py`:

| Table | Key | Purpose |
|---|---|---|
| keywords | keyword | Saved niches |
| listings | listing_id | Latest normalized data, shop ID, explicit watch flag |
| keyword_listings | keyword + listing_id | Many-to-many keyword discovery membership |
| snapshots | listing_id + UTC day | Timestamp, nullable favorites, quantity, views, shop sales |
| api_usage | UTC day | Persistent request-attempt budget |

SQLite uses WAL mode, foreign keys, parameterized queries, and a 30-second lock timeout. Shop totals are duplicated in listing snapshots for a simple starter; do not sum them across a shop's listings. Stored snapshots have actual observation timestamps; daily observations do not give precise intraday timing.

## Metrics and limits

- Price uses Etsy's Money `amount / divisor` and retains currency. There is no cross-currency price comparison or conversion.
- Age is based on `original_creation_timestamp`. Trend velocity is `favorites / max(age_days, 1)`. It is a lifetime average, not recent favorite growth. Missing age/favorites produces null.
- Tags are normalized exact phrases, counted once per listing. Listings may expose fewer than 13 tags. Frequency is within the returned sample; it does not measure search demand, tag conversion, or causal performance. The sample is ranked by Etsy relevance, not sales, and capped at 100 per manual search.
- Weekly deltas compare the latest successful observation with exactly seven UTC calendar dates earlier. Missing baseline produces null. `last_snapshot` exposes freshness; old data remains old until collection succeeds. Eight daily observations produce the first full seven-day delta.
- Positive **net stock drop** is an uncertain sales proxy. Restocks, seller edits, variations, multi-unit purchases, and renewals can distort it. Negative values expose restocks rather than being silently clamped. No sum of daily drops is presented as confirmed sales.
- **Shop sales growth** is shop-wide. Never assign it to one product or sum duplicate shop totals.
- `999 - quantity` is deliberately excluded: digital listings do not have a universal verified 999 starting stock. A current quantity cannot establish historical sales.
- Breakout is an explicit heuristic: seven-day favorites growth >= 10 and >= 25% of the baseline. Change `app/metrics.py` to tune it.
- 14–30 days provides more observations, not guaranteed sales accuracy. Public listing data cannot reliably yield true listing-level weekly sales. Authorized own-shop transaction data would be needed for confirmed units/revenue.
- Fields that Etsy omits or makes inaccessible remain null. Shop lookup failures retain listing results with warnings. Inactive/removed listing failures are logged without synthetic snapshots.

## API

- `GET /search?keyword=...&limit=50`
- `GET /watchlist`
- `POST /watchlist/keywords` with `{"keyword":"editable invitation"}`
- `DELETE /watchlist/keywords?keyword=...`
- `POST /watchlist/listings/{listing_id}`
- `DELETE /watchlist/listings/{listing_id}`

Keep both servers on localhost. This personal starter has no application authentication or multiuser isolation; hosting publicly requires access controls, deployment configuration, and review of Etsy's current API terms and caching/retention requirements. No live scheduler or cloud hosting is configured.

## Verification

```bash
python -m pytest -q
```

Tests use isolated SQLite databases and mock Etsy responses. They cover money/age, missing fields, tag deduplication, weekly baseline requirements, restocks, idempotent snapshots, API validation, keyword persistence, authentication header construction, and request budgets. Live integration still requires your approved app credentials.

## Etsy references

- Current machine-readable specification: https://www.etsy.com/openapi/generated/oas/3.0.0.json
- API reference: https://developers.etsy.com/documentation/reference/
- Authentication: https://developers.etsy.com/documentation/essentials/authentication/
- Rate limits: https://developers.etsy.com/documentation/essentials/rate-limits/

Endpoint contracts and header format checked against Etsy's published specification on 2026-11-15.
