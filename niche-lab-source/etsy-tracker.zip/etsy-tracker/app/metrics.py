from collections import Counter
from datetime import datetime, timezone, timedelta
from html import unescape

def normalize(item, shop=None, now=None):
    now = now or datetime.now(timezone.utc)
    created = item.get('original_creation_timestamp')
    age = max(0, (now.timestamp() - created) / 86400) if created else None
    money = item.get('price') or {}
    divisor = money.get('divisor')
    favorites = item.get('num_favorers')
    return {
        'listing_id': item['listing_id'], 'title': unescape(item.get('title', '')),
        'url': f"https://www.etsy.com/listing/{item['listing_id']}",
        'shop_id': item.get('shop_id'),
        'price': money.get('amount', 0) / divisor if divisor else None,
        'currency': money.get('currency_code'),
        'age_days': round(age, 2) if age is not None else None,
        'favorites': favorites, 'quantity': item.get('quantity'),
        'views': item.get('views'), 'shop_sales': (shop or {}).get('transaction_sold_count'),
        'trend_velocity': round(favorites / max(age, 1), 3) if favorites is not None and age is not None else None,
        'tags': item.get('tags') or [], 'listing_type': item.get('listing_type'),
    }

def tags_for(rows):
    counts = Counter(tag.strip().casefold() for row in rows
                     for tag in set(str(t).strip().casefold() for t in row.get('tags', []) if str(t).strip()))
    return [{'tag': tag, 'listing_count': count, 'sample_percent': round(100 * count / len(rows), 1)}
            for tag, count in counts.most_common()]

def weekly(history):
    result = {'favorite_growth_7d': None, 'net_stock_drop_7d': None,
              'shop_sales_growth_7d': None, 'breakout': False, 'history_days': len(history)}
    if not history:
        return result
    latest = history[-1]
    target = (datetime.fromisoformat(latest['day']) - timedelta(days=7)).date().isoformat()
    baseline = next((h for h in history if h['day'] == target), None)
    if baseline is None:
        return result
    for output, field in [('favorite_growth_7d','favorites'), ('net_stock_drop_7d','quantity'), ('shop_sales_growth_7d','shop_sales')]:
        a, b = baseline[field], latest[field]
        if a is not None and b is not None:
            result[output] = a - b if field == 'quantity' else b - a
    result['breakout'] = (result['favorite_growth_7d'] or 0) >= max(10, (baseline['favorites'] or 0) * .25)
    return result
