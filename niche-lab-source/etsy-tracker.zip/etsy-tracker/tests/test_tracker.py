from datetime import datetime, timezone
from fastapi.testclient import TestClient
from app.metrics import normalize, tags_for, weekly
from app.db import init, connect
from app.service import save
from app.api import app
from app.etsy import EtsyClient, EtsyError
import httpx
import pytest

@pytest.fixture(autouse=True)
def database(tmp_path, monkeypatch):
    monkeypatch.setenv('DATABASE_PATH', str(tmp_path / 'test.sqlite3'))
    init()

def test_age_money_missing_fields():
    now = datetime(2026, 1, 10, tzinfo=timezone.utc)
    row = normalize({'listing_id': 1, 'original_creation_timestamp': now.timestamp(),
                     'num_favorers': 5, 'price': {'amount': 1299, 'divisor': 100, 'currency_code': 'USD'}}, now=now)
    assert row['trend_velocity'] == 5
    assert row['price'] == 12.99
    assert row['shop_sales'] is None
    assert normalize({'listing_id': 2})['trend_velocity'] is None

def test_tags_count_listings_not_duplicates():
    assert tags_for([{'tags': ['Birthday', ' birthday ', 'Party']}, {'tags': ['birthday']}])[0] == {
        'tag': 'birthday', 'listing_count': 2, 'sample_percent': 100.0}

def test_weekly_requires_seven_day_baseline_and_preserves_restock():
    a = {'day': '2026-01-01', 'favorites': 20, 'quantity': 10, 'shop_sales': 100}
    b = {'day': '2026-01-08', 'favorites': 31, 'quantity': 15, 'shop_sales': 120}
    result = weekly([a, b])
    assert result['breakout']
    assert result['net_stock_drop_7d'] == -5
    assert result['shop_sales_growth_7d'] == 20
    assert weekly([b])['favorite_growth_7d'] is None
    assert weekly([a, {**b, 'day': '2026-01-09'}])['favorite_growth_7d'] is None

def test_snapshot_idempotency():
    row = normalize({'listing_id': 1, 'num_favorers': 2})
    save(row, watched=True, snapshot=True)
    save({**row, 'favorites': 8}, snapshot=True)
    with connect() as con:
        assert con.execute('SELECT count(*) FROM snapshots').fetchone()[0] == 1
        assert con.execute('SELECT favorites FROM snapshots').fetchone()[0] == 2
        assert con.execute('SELECT watched FROM listings').fetchone()[0] == 1

def test_api_search_and_validation(monkeypatch):
    monkeypatch.setenv('ETSY_KEYSTRING', 'test')
    monkeypatch.setenv('ETSY_SHARED_SECRET', 'test')
    monkeypatch.setattr(EtsyClient, 'search', lambda *args: [{'listing_id': 1, 'shop_id': 9, 'tags': ['invite']}])
    monkeypatch.setattr(EtsyClient, 'shop', lambda *args: {'transaction_sold_count': 12})
    with TestClient(app) as client:
        result = client.get('/search', params={'keyword': 'invite'}).json()
        assert result['listings'][0]['shop_sales'] == 12
        assert result['tags'][0]['tag'] == 'invite'
        assert client.get('/search', params={'keyword': '  '}).status_code == 422
        assert client.get('/search', params={'keyword': 'x', 'limit': 101}).status_code == 422
        assert client.post('/watchlist/keywords', json={'keyword': ' Invite '}).status_code == 200
        assert client.get('/watchlist').json()['keywords'] == ['invite']
        assert client.delete('/watchlist/keywords', params={'keyword': 'invite'}).status_code == 200

def test_request_budget_and_header(monkeypatch):
    monkeypatch.setenv('ETSY_KEYSTRING', 'testkey')
    monkeypatch.setenv('ETSY_SHARED_SECRET', 'testsecret')
    monkeypatch.setenv('MAX_DAILY_REQUESTS', '1')
    client = EtsyClient()
    client.http.close()
    def handler(request):
        assert request.headers['x-api-key'] == 'testkey:testsecret'
        return httpx.Response(200, json={'results': []})
    client.http = httpx.Client(base_url='https://openapi.etsy.com/v3/application/',
                              headers={'x-api-key': 'testkey:testsecret'}, transport=httpx.MockTransport(handler))
    assert client.search('invite') == []
    with pytest.raises(EtsyError, match='budget'):
        client.search('invite')
    client.close()
