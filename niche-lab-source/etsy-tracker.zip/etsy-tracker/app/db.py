import os
import sqlite3
from pathlib import Path
from contextlib import contextmanager
from dotenv import load_dotenv

load_dotenv()
SCHEMA = '''
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS keywords (
 keyword TEXT PRIMARY KEY, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS listings (
 listing_id INTEGER PRIMARY KEY, title TEXT NOT NULL, shop_id INTEGER,
 payload TEXT NOT NULL, watched INTEGER NOT NULL DEFAULT 0,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS keyword_listings (
 keyword TEXT NOT NULL REFERENCES keywords(keyword) ON DELETE CASCADE,
 listing_id INTEGER NOT NULL REFERENCES listings(listing_id),
 PRIMARY KEY(keyword, listing_id)
);
CREATE TABLE IF NOT EXISTS snapshots (
 listing_id INTEGER NOT NULL REFERENCES listings(listing_id),
 day TEXT NOT NULL, observed_at TEXT NOT NULL, favorites INTEGER,
 quantity INTEGER, views INTEGER, shop_sales INTEGER,
 PRIMARY KEY(listing_id, day)
);
CREATE TABLE IF NOT EXISTS api_usage (
 day TEXT PRIMARY KEY, requests INTEGER NOT NULL DEFAULT 0
);
'''

@contextmanager
def connect():
    path = Path(os.getenv('DATABASE_PATH', 'data/tracker.sqlite3'))
    path.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(path, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()

def init():
    with connect() as con:
        con.executescript(SCHEMA)
