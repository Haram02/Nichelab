import os
import time
from datetime import datetime, timezone
import httpx
from .db import connect

class EtsyError(Exception):
    pass

class EtsyClient:
    def __init__(self):
        key, secret = os.getenv('ETSY_KEYSTRING'), os.getenv('ETSY_SHARED_SECRET')
        if not key or not secret:
            raise EtsyError('Set ETSY_KEYSTRING and ETSY_SHARED_SECRET in .env, then restart.')
        self.http = httpx.Client(base_url='https://openapi.etsy.com/v3/application/',
                                 headers={'x-api-key': f'{key}:{secret}'}, timeout=25)
        self.shops = {}

    def close(self):
        self.http.close()

    def get(self, path, **params):
        for attempt in range(3):
            # Persistent counter covers this installation, including retry attempts.
            day = datetime.now(timezone.utc).date().isoformat()
            with connect() as con:
                con.execute('BEGIN IMMEDIATE')
                con.execute('INSERT OR IGNORE INTO api_usage(day) VALUES (?)', (day,))
                count = con.execute('SELECT requests FROM api_usage WHERE day=?', (day,)).fetchone()[0]
                if count >= int(os.getenv('MAX_DAILY_REQUESTS', '4500')):
                    raise EtsyError('Local daily request budget reached.')
                con.execute('UPDATE api_usage SET requests=requests+1 WHERE day=?', (day,))
            try:
                res = self.http.get(path, params=params)
            except httpx.RequestError:
                if attempt == 2:
                    raise EtsyError('Etsy network request failed. Try again later.') from None
                time.sleep(2 ** attempt)
                continue
            if res.status_code == 429:
                try:
                    delay = float(res.headers.get('retry-after', '2'))
                except ValueError:
                    delay = 2
                if delay > 30 or attempt == 2:
                    raise EtsyError('Etsy rate limit reached. Retry later.')
                time.sleep(max(1, delay))
                continue
            if res.status_code >= 500 and attempt < 2:
                time.sleep(2 ** attempt)
                continue
            if res.status_code != 200:
                raise EtsyError(f'Etsy returned HTTP {res.status_code}. Check app access and credentials; unavailable listings may be inactive.')
            return res.json()
        raise EtsyError('Etsy unavailable.')

    def search(self, keyword, limit=50):
        return self.get('listings/active', keywords=keyword, limit=limit,
                        sort_on='score', sort_order='desc').get('results', [])

    def listing(self, listing_id):
        return self.get(f'listings/{listing_id}')

    def shop(self, shop_id):
        if shop_id not in self.shops:
            self.shops[shop_id] = self.get(f'shops/{shop_id}')
        return self.shops[shop_id]
