import os
import httpx
import pandas as pd
import streamlit as st
from dotenv import load_dotenv

load_dotenv()
st.set_page_config(page_title='Etsy Niche Lab', page_icon='🔎', layout='wide')
st.title('Etsy Niche Lab')
st.caption('Personal market research · targeted searches · daily observations')
BASE = os.getenv('API_URL', 'http://127.0.0.1:8000').rstrip('/')

def request(method, path, **kwargs):
    try:
        r = httpx.request(method, BASE + path, timeout=180, **kwargs)
        if r.is_error:
            try:
                detail = r.json().get('detail', 'Request failed')
            except ValueError:
                detail = 'Request failed'
            st.error(str(detail))
            return None
        return r.json()
    except httpx.RequestError:
        st.error('Backend unavailable or request timed out. Start FastAPI and check API_URL.')
        return None

def table(rows):
    if rows:
        frame = pd.DataFrame(rows).drop(columns=['tags'], errors='ignore')
        st.dataframe(frame, use_container_width=True, hide_index=True,
                     column_config={'url': st.column_config.LinkColumn('Listing')})
    else:
        st.info('No listings yet.')

search, watch, about = st.tabs(['Keyword search', 'Watchlist & weekly signals', 'How to read the data'])
with search:
    with st.form('search'):
        keyword = st.text_input('Search a niche', placeholder='editable birthday invitation', max_chars=200)
        limit = st.slider('Result sample', 10, 100, 50, 10)
        submitted = st.form_submit_button('Research keyword', type='primary')
    if submitted and keyword.strip():
        with st.spinner('Fetching listings and shop metrics…'):
            result = request('GET', '/search', params={'keyword': keyword.strip(), 'limit': limit})
        if result is not None:
            st.session_state['result'] = result
    result = st.session_state.get('result')
    if result is not None:
        rows = result['listings']
        st.metric('Listings in sample', len(rows))
        for warning in result['warnings']:
            st.warning(warning)
        st.subheader('Search results')
        st.caption('Click a column heading to sort. Prices retain their currency; compare within a currency.')
        table(rows)
        st.subheader('Tag analyzer')
        st.caption('Exact tag phrases, normalized for case and spacing. Frequency measures this sample, not search volume or conversion.')
        st.dataframe(result['tags'], use_container_width=True, hide_index=True)
        if rows:
            st.download_button('Download results CSV', pd.DataFrame(rows).to_csv(index=False), 'etsy-search.csv', 'text/csv')
with watch:
    c1, c2 = st.columns(2)
    with c1:
        with st.form('keyword_watch'):
            kw = st.text_input('Keyword to track daily', max_chars=200)
            if st.form_submit_button('Save keyword') and kw.strip():
                if request('POST', '/watchlist/keywords', json={'keyword': kw.strip()}):
                    st.success('Saved. Daily job will discover up to 20 listings per keyword.')
    with c2:
        with st.form('listing_watch'):
            lid = st.text_input('Individual listing ID')
            if st.form_submit_button('Save listing'):
                if lid.isdigit() and int(lid) > 0:
                    if request('POST', f'/watchlist/listings/{int(lid)}'):
                        st.success('Saved with first snapshot.')
                else:
                    st.error('Enter a positive numeric listing ID.')
    if st.button('Refresh watchlist'):
        st.rerun()
    data = request('GET', '/watchlist')
    if data:
        st.write('Tracked keywords:', ', '.join(data['keywords']) or 'None')
        table(data['listings'])
        with st.expander('Remove tracked items'):
            remove_kw = st.selectbox('Keyword', [''] + data['keywords'])
            if st.button('Remove keyword') and remove_kw:
                request('DELETE', '/watchlist/keywords', params={'keyword': remove_kw})
                st.rerun()
            remove_id = st.text_input('Listing ID to remove (deletes its history)')
            if st.button('Remove listing') and remove_id.isdigit():
                request('DELETE', f'/watchlist/listings/{int(remove_id)}')
                st.rerun()
with about:
    st.markdown('''
- **Trend velocity:** favorites ÷ max(age in days, 1), using original creation time.
- **Weekly growth:** latest successful snapshot compared with the snapshot exactly seven UTC dates earlier. Missing baseline means no value.
- **Net stock drop:** baseline quantity − latest quantity. Positive values may indicate sales; restocks, variations, edits, and renewals make this uncertain.
- **Shop sales growth:** shop-wide change, never assigned to an individual listing.
- **Breakout flag:** at least 10 additional favorites and at least 25% growth over seven days. This is an adjustable heuristic.
- **Digital inventory:** 999 is not a verified starting quantity. `999 − quantity` is not a defensible sales estimate and is deliberately excluded.
- **History:** 14–30 days adds context, but cannot guarantee accurate sales estimates. Unavailable fields remain empty.

The daily job is a separate process. Start it with your OS scheduler; this dashboard does not schedule work. Keep the API and dashboard bound to localhost for personal use.
''')
