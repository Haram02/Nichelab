from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field
from .db import init, connect
from .etsy import EtsyClient, EtsyError
from .metrics import tags_for
from .service import enrich, save, watchlist

@asynccontextmanager
async def lifespan(app):
    init()
    yield

app = FastAPI(title='Personal Etsy Research', lifespan=lifespan)

class Keyword(BaseModel):
    keyword: str = Field(min_length=1, max_length=200)

@app.get('/health')
def health():
    return {'status': 'ok'}

@app.get('/search')
def search(keyword: str = Query(min_length=1, max_length=200), limit: int = Query(50, ge=1, le=100)):
    keyword = keyword.strip()
    if not keyword:
        raise HTTPException(422, 'Keyword cannot be blank.')
    client = None
    try:
        client = EtsyClient()
        warnings = []
        rows = [enrich(client, item, warnings) for item in client.search(keyword, limit)]
        return {'listings': rows, 'tags': tags_for(rows), 'warnings': sorted(set(warnings)), 'sample_size': len(rows)}
    except EtsyError as exc:
        raise HTTPException(502, str(exc)) from None
    finally:
        if client:
            client.close()

@app.get('/watchlist')
def get_watchlist():
    with connect() as con:
        keywords = [r[0] for r in con.execute('SELECT keyword FROM keywords ORDER BY keyword')]
    return {'keywords': keywords, 'listings': watchlist()}

@app.post('/watchlist/keywords')
def add_keyword(body: Keyword):
    keyword = body.keyword.strip().casefold()
    if not keyword:
        raise HTTPException(422, 'Keyword cannot be blank.')
    with connect() as con:
        con.execute('BEGIN IMMEDIATE')
        if con.execute('SELECT count(*) FROM keywords').fetchone()[0] >= 50 and not con.execute('SELECT 1 FROM keywords WHERE keyword=?', (keyword,)).fetchone():
            raise HTTPException(409, '50 keyword limit reached.')
        con.execute('INSERT OR IGNORE INTO keywords(keyword) VALUES (?)', (keyword,))
    return {'keyword': keyword, 'status': 'saved; discovery occurs on next daily run'}

@app.delete('/watchlist/keywords')
def remove_keyword(keyword: str):
    with connect() as con:
        con.execute('DELETE FROM keywords WHERE keyword=?', (keyword.strip().casefold(),))
    return {'status': 'removed'}

@app.post('/watchlist/listings/{listing_id}')
def add_listing(listing_id: int):
    if listing_id <= 0:
        raise HTTPException(422, 'Listing ID must be positive.')
    client = None
    try:
        client = EtsyClient()
        warnings = []
        row = enrich(client, client.listing(listing_id), warnings)
        save(row, watched=True, snapshot=True)
        return {'listing': row, 'warnings': warnings}
    except EtsyError as exc:
        raise HTTPException(502, str(exc)) from None
    except ValueError as exc:
        raise HTTPException(409, str(exc)) from None
    finally:
        if client:
            client.close()

@app.delete('/watchlist/listings/{listing_id}')
def remove_listing(listing_id: int):
    with connect() as con:
        con.execute('DELETE FROM keyword_listings WHERE listing_id=?', (listing_id,))
        con.execute('DELETE FROM snapshots WHERE listing_id=?', (listing_id,))
        con.execute('DELETE FROM listings WHERE listing_id=?', (listing_id,))
    return {'status': 'removed; keyword discovery may add it again'}
